
## Atualização das abas (Entradas & Saídas e Conciliação)
- Os arquivos originais foram preservados como `page.backup.tsx` em cada pasta.
- Para voltar ao anterior, basta renomear `page.backup.tsx` para `page.tsx`.
- As novas páginas usam Supabase (Service Role Key) e os componentes de edição por linha.
